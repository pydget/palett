from palett.card import Card

yellow = Card(
    base='#FFEB3B',
    lighten_5='#FFFDE7',
    lighten_4='#FFF9C4',
    lighten_3='#FFF59D',
    lighten_2='#FFF176',
    lighten_1='#FFEE58',
    darken_1='#FDD835',
    darken_2='#FBC02D',
    darken_3='#F9A825',
    darken_4='#F57F17',
    accent_1='#FFFF8D',
    accent_2='#FFFF00',
    accent_3='#FFEA00',
    accent_4='#FFD600'
)
