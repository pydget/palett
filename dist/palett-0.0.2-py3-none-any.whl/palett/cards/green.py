from palett.card import Card

green = Card(
    base='#4CAF50',
    lighten_5='#E8F5E9',
    lighten_4='#C8E6C9',
    lighten_3='#A5D6A7',
    lighten_2='#81C784',
    lighten_1='#66BB6A',
    darken_1='#43A047',
    darken_2='#388E3C',
    darken_3='#2E7D32',
    darken_4='#1B5E20',
    accent_1='#B9F6CA',
    accent_2='#69F0AE',
    accent_3='#00E676',
    accent_4='#00C853'
)
