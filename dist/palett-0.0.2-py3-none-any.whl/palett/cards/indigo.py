from palett.card import Card

indigo = Card(
    base='#3F51B5',
    lighten_5='#E8EAF6',
    lighten_4='#C5CAE9',
    lighten_3='#9FA8DA',
    lighten_2='#7986CB',
    lighten_1='#5C6BC0',
    darken_1='#3949AB',
    darken_2='#303F9F',
    darken_3='#283593',
    darken_4='#1A237E',
    accent_1='#8C9EFF',
    accent_2='#536DFE',
    accent_3='#3D5AFE',
    accent_4='#304FFE'
)
