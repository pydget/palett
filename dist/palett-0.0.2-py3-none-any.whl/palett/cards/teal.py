from palett.card import Card

teal = Card(
    base='#009688',
    lighten_5='#E0F2F1',
    lighten_4='#B2DFDB',
    lighten_3='#80CBC4',
    lighten_2='#4DB6AC',
    lighten_1='#26A69A',
    darken_1='#00897B',
    darken_2='#00796B',
    darken_3='#00695C',
    darken_4='#004D40',
    accent_1='#A7FFEB',
    accent_2='#64FFDA',
    accent_3='#1DE9B6',
    accent_4='#00BFA5'
)
