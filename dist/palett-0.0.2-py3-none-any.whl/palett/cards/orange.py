from palett.card import Card

orange = Card(
    base='#FF9800',
    lighten_5='#FFF3E0',
    lighten_4='#FFE0B2',
    lighten_3='#FFCC80',
    lighten_2='#FFB74D',
    lighten_1='#FFA726',
    darken_1='#FB8C00',
    darken_2='#F57C00',
    darken_3='#EF6C00',
    darken_4='#E65100',
    accent_1='#FFD180',
    accent_2='#FFAB40',
    accent_3='#FF9100',
    accent_4='#FF6D00'
)
