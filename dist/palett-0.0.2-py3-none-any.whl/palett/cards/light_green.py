from palett.card import Card

light_green = Card(
    base='#8BC34A',
    lighten_5='#F1F8E9',
    lighten_4='#DCEDC8',
    lighten_3='#C5E1A5',
    lighten_2='#AED581',
    lighten_1='#9CCC65',
    darken_1='#7CB342',
    darken_2='#689F38',
    darken_3='#558B2F',
    darken_4='#33691E',
    accent_1='#CCFF90',
    accent_2='#B2FF59',
    accent_3='#76FF03',
    accent_4='#64DD17'
)
