def leverage(hsl, base):
    hu, sa, li = hsl
    return hu / base, sa / base, li / base
