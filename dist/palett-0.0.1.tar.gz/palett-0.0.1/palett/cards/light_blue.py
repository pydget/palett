from palett.card import Card

light_blue = Card(
    base='#03A9F4',
    lighten_5='#E1F5FE',
    lighten_4='#B3E5FC',
    lighten_3='#81D4FA',
    lighten_2='#4FC3F7',
    lighten_1='#29B6F6',
    darken_1='#039BE5',
    darken_2='#0288D1',
    darken_3='#0277BD',
    darken_4='#01579B',
    accent_1='#80D8FF',
    accent_2='#40C4FF',
    accent_3='#00B0FF',
    accent_4='#0091EA'
)
