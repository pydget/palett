from palett.card import Card

brown = Card(
    base='#795548',
    lighten_5='#EFEBE9',
    lighten_4='#D7CCC8',
    lighten_3='#BCAAA4',
    lighten_2='#A1887F',
    lighten_1='#8D6E63',
    darken_1='#6D4C41',
    darken_2='#5D4037',
    darken_3='#4E342E',
    darken_4='#3E2723',
    accent_1='#D2BEB6',
    accent_2='#B59387',
    accent_3='#A27767',
    accent_4='#855F51',
)
