from palett.card import Card

blue = Card(
    base='#2196F3',
    lighten_5='#E3F2FD',
    lighten_4='#BBDEFB',
    lighten_3='#90CAF9',
    lighten_2='#64B5F6',
    lighten_1='#42A5F5',
    darken_1='#1E88E5',
    darken_2='#1976D2',
    darken_3='#1565C0',
    darken_4='#0D47A1',
    accent_1='#82B1FF',
    accent_2='#448AFF',
    accent_3='#2979FF',
    accent_4='#2962FF'
)
