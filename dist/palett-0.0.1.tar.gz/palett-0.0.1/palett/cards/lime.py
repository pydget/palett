from palett.card import Card

lime = Card(
    base='#CDDC39',
    lighten_5='#F9FBE7',
    lighten_4='#F0F4C3',
    lighten_3='#E6EE9C',
    lighten_2='#DCE775',
    lighten_1='#D4E157',
    darken_1='#C0CA33',
    darken_2='#AFB42B',
    darken_3='#9E9D24',
    darken_4='#827717',
    accent_1='#F4FF81',
    accent_2='#EEFF41',
    accent_3='#C6FF00',
    accent_4='#AEEA00'
)
