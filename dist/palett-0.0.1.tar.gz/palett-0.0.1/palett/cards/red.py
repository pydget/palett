from palett.card import Card

red = Card(
    base='#F44336',
    lighten_5='#FFEBEE',
    lighten_4='#FFCDD2',
    lighten_3='#EF9A9A',
    lighten_2='#E57373',
    lighten_1='#EF5350',
    darken_1='#E53935',
    darken_2='#D32F2F',
    darken_3='#C62828',
    darken_4='#B71C1C',
    accent_1='#FF8A80',
    accent_2='#FF5252',
    accent_3='#FF1744',
    accent_4='#D50000'
)
