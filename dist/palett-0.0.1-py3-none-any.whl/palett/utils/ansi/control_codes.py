CLR_ALL = '0'
ESC = '\u001b'
L = ESC + '['
R = 'm'
SC = ';'

# Escapes = {
#     'simple': '\e',
#     'utf8oct': '\033',
#     'utf8hex': '\x1b',
#     'unicode': '\u001b'  # C/C++/Java/Python
# }
