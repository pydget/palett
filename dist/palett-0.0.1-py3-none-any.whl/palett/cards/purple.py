from palett.card import Card

purple = Card(
    base='#9C27B0',
    lighten_5='#F3E5F5',
    lighten_4='#E1BEE7',
    lighten_3='#CE93D8',
    lighten_2='#BA68C8',
    lighten_1='#AB47BC',
    darken_1='#8E24AA',
    darken_2='#7B1FA2',
    darken_3='#6A1B9A',
    darken_4='#4A148C',
    accent_1='#EA80FC',
    accent_2='#E040FB',
    accent_3='#D500F9',
    accent_4='#AA00FF'
)
