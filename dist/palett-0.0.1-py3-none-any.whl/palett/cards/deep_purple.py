from palett.card import Card

deep_purple = Card(
    base='#673AB7',
    lighten_5='#EDE7F6',
    lighten_4='#D1C4E9',
    lighten_3='#B39DDB',
    lighten_2='#9575CD',
    lighten_1='#7E57C2',
    darken_1='#5E35B1',
    darken_2='#512DA8',
    darken_3='#4527A0',
    darken_4='#311B92',
    accent_1='#B388FF',
    accent_2='#7C4DFF',
    accent_3='#651FFF',
    accent_4='#6200EA'
)
