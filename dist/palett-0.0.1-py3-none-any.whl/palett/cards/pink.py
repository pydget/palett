from palett.card import Card

pink = Card(
    base='#E91E63',
    lighten_5='#FCE4EC',
    lighten_4='#F8BBD0',
    lighten_3='#F48FB1',
    lighten_2='#F06292',
    lighten_1='#EC407A',
    darken_1='#D81B60',
    darken_2='#C2185B',
    darken_3='#AD1457',
    darken_4='#880E4F',
    accent_1='#FF80AB',
    accent_2='#FF4081',
    accent_3='#F50057',
    accent_4='#C51162'
)
