from dataclasses import dataclass


@dataclass
class Preset:
    max: str
    min: str
    na: str
