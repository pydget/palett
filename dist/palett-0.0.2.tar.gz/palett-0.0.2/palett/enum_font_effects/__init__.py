BOLD = 'bold'
ITALIC = 'italic'
UNDERLINE = 'underline'
INVERSE = 'inverse'
