from palett.card import Card

blue_grey = Card(
    base='#607D8B',
    lighten_5='#ECEFF1',
    lighten_4='#CFD8DC',
    lighten_3='#B0BEC5',
    lighten_2='#90A4AE',
    lighten_1='#78909C',
    darken_1='#546E7A',
    darken_2='#455A64',
    darken_3='#37474F',
    darken_4='#263238',
    accent_1='#B7C9D1',
    accent_2='#89A5B3',
    accent_3='#6A8EA0',
    accent_4='#547383'
)
