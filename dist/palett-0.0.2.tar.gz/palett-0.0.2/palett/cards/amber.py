from palett.card import Card

amber = Card(
    base='#FFC107',
    lighten_5='#FFF8E1',
    lighten_4='#FFECB3',
    lighten_3='#FFE082',
    lighten_2='#FFD54F',
    lighten_1='#FFCA28',
    darken_1='#FFB300',
    darken_2='#FFA000',
    darken_3='#FF8F00',
    darken_4='#FF6F00',
    accent_1='#FFE57F',
    accent_2='#FFD740',
    accent_3='#FFC400',
    accent_4='#FFAB00'
)
